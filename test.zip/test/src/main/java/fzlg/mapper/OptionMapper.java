package fzlg.mapper;

import fzlg.entity.Option;

public interface OptionMapper {
    void insert(Option o);
}
