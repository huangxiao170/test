package fzlg.mapper;

import fzlg.entity.Examination;

public interface ExaminationMapper {
    void insert(Examination examination);
}
