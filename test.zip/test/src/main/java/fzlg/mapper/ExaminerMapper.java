package fzlg.mapper;

import fzlg.entity.Examiner;

public interface ExaminerMapper {
    Examiner selectByUsername(String username);
}
