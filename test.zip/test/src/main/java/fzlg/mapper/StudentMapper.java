package fzlg.mapper;

import fzlg.entity.Student;

public interface StudentMapper {
    int insert(Student student);

    Student selectBystudent_number(String student_number);
}
