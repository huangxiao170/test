package fzlg.mapper;

import fzlg.entity.Question;

public interface QuestionMapper {
    void insert(Question q);
}
