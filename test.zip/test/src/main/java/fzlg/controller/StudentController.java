package fzlg.controller;

import fzlg.entity.Examiner;
import fzlg.entity.Student;
import fzlg.service.ExaminerService;
import fzlg.service.StudentService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.Collections;
import java.util.Map;

@RestController
public class StudentController {
    @Resource
    private StudentService studentService;
    @Resource
    private ExaminerService examinerService;
    @RequestMapping("/reg")
    public String reg(Student student) {
        System.out.println(student);
        String student_number = student.getStudent_number();
        Student stu = studentService.getBystudent_number(student_number);
        if (null != stu) {
            return "这个学号已注册";
        }
        int i = studentService.reg(student);


        return i > 0 ? "注册成功" : "注册失败";
    }
    @RequestMapping("/login")
    public String login(Student student) {
        String student_number = student.getStudent_number();
        String password = student.getPassword();
        if ( null== student_number || "".equals(student_number)) {
            return "学号不能为空";
        }
        Student stu = studentService.getBystudent_number(student_number);
        if (null == stu || !stu.getPassword().equals(password)) {
            return "学号未注册或者密码错误";
        }
        return "登录成功";
    }
    @PostMapping("/examiner")
    public Map<String, String> examiner(@RequestBody Examiner examiner, HttpSession session) {
        String username = examiner.getUsername();
        String password = examiner.getPassword();
        if (null == username || "".equals(username)) {
            return Collections.singletonMap("message", "用户名不能为空");
        }
        Examiner exa = examinerService.getByUsername(username);
        if (null == exa || !exa.getPassword().equals(password)) {
            return Collections.singletonMap("message", "用户名未注册或者密码错误");
        }
        session.setAttribute("loginExaminer",exa);
        return Collections.emptyMap();
    }
}

