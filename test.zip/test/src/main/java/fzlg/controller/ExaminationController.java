package fzlg.controller;

import fzlg.entity.ExaminationQo;
import fzlg.entity.Examiner;
import fzlg.service.ExaminationService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("/examination")
public class ExaminationController {
    @Resource
    private ExaminationService examinationService;

    @PostMapping(value = "/create_new", consumes = "application/json", produces = "application/json")
    public String createNew(@RequestBody ExaminationQo examinationQo, HttpSession session) {
        System.out.println(examinationQo);

        Examiner exa = (Examiner) session.getAttribute("loginExaminer");
        if (null == exa) {
            return "请先登录";
        }

        int id = exa.getId();// 当前登录的教师id
        examinationService.addExamination(id, examinationQo);
        return "ok";
    }
}
