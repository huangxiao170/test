package fzlg.service;

import fzlg.entity.Examiner;
import fzlg.mapper.ExaminerMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class ExaminerServiceImpl implements ExaminerService {
    @Resource
    private ExaminerMapper examinerMapper;

    @Override
    public Examiner getByUsername(String username) {
        return examinerMapper.selectByUsername(username);
    }
}