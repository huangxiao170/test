package fzlg.service;

import fzlg.entity.Student;
import fzlg.mapper.StudentMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class StudentServiceImpl implements StudentService {
    @Resource
    private StudentMapper studentMapper;

    @Override
    public int reg(Student student) {
        return studentMapper.insert(student);
    }

    @Override
    public Student getBystudent_number(String student_number) {
        return studentMapper.selectBystudent_number(student_number);
    }

}


