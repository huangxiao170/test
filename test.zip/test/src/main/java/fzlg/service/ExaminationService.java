package fzlg.service;

import fzlg.entity.ExaminationQo;

public interface ExaminationService {
    void addExamination(int id, ExaminationQo examinationQo);
}
