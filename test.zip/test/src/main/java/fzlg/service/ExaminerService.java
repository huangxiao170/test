package fzlg.service;

import fzlg.entity.Examiner;

public interface ExaminerService {
    Examiner getByUsername(String username);
}
