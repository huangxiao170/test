package fzlg.service;

import fzlg.entity.Student;

public interface StudentService {
    int reg(Student student);
    Student getBystudent_number(String student_number);

}
