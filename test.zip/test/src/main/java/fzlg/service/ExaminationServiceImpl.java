package fzlg.service;

import fzlg.entity.Examination;
import fzlg.entity.ExaminationQo;
import fzlg.entity.Option;
import fzlg.entity.Question;
import fzlg.mapper.ExaminationMapper;
import fzlg.mapper.OptionMapper;
import fzlg.mapper.QuestionMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import javax.annotation.Resource;

@Service
public class ExaminationServiceImpl implements ExaminationService {
    @Resource
    private ExaminationMapper examinationMapper;
    @Resource
    private QuestionMapper questionMapper;
    @Resource
    private OptionMapper optionMapper;

    @Override
    @Transactional// 事务控制
    public void addExamination(int id, ExaminationQo examinationQo) {
        // 插入试卷表
        Examination examination = new Examination();
        examination.setExaminerId(id);
        examination.setTitle(examinationQo.getTitle());
        examination.setStatus(0);
        examinationMapper.insert(examination);
        int eid = examination.getId();

        try {
            // 循环插入题目和选项数据
            for (Question q : examinationQo.getQuestionList()) {
                q.setExaminationId(eid);
                questionMapper.insert(q);
                int qid = q.getId();
                for (Option o : q.getOptions()) {
                    o.setQuestionId(qid);
                    optionMapper.insert(o);
                }
            }
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            throw e;
        }
    }
}
