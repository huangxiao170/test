package fzlg.entity;

import lombok.Data;

@Data
public class Option {
    private int id;
    private int questionId;//选项属于哪个题目

    private String label;//选项名称
    private String value;//选项内容
}
