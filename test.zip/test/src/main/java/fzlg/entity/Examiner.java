package fzlg.entity;

import lombok.Data;

@Data
public class Examiner {
    private int id;
    private String username;
    private String password;
}
