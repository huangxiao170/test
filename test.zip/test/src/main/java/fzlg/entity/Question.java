package fzlg.entity;

import lombok.Data;

import java.util.List;

@Data
public class Question {
    private int id;
    private int examinationId;//试卷id
    private String  questionTitle;
    private String  type;
    private int score;
    private String  answer;
    private List<Option> options;

}
