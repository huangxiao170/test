package fzlg.entity;

import lombok.Data;

@Data
public class Examination {
    private int id;
    private int examinerId;//哪个老师出的卷子
    private String title;
    private int status;//试卷
    private Data startTime;//开始考试时间
    private Data endTime;


}
