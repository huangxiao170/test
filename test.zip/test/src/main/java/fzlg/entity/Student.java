package fzlg.entity;

import lombok.Data;

@Data
public class Student {
    private  int id;
    private  String student_number;
    private  String name;
    private  String password;
    private  String confirmPassword;

}
