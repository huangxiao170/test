package fzlg.entity;

import lombok.Data;

import java.util.List;

@Data
public class ExaminationQo {
    private String title;
    private List<Question> questionList;
}
