var app = new Vue({
    el: '#app',
    data: {
        questionList:[],
        title:'',
        currentQuestion:null,
    },
    methods: {
       add(type){
           var labels=['A','B','C','D'];
           let options=[];
           var len=type==='boolean'?2:4;
           for (var i=0;i<len;i++){
               options.push({
                   label:labels[i],
                   value:'',
                   index:i+1
               })
           }
           var question={
               type:type,
               questionTitle:'',
               score:0,
               options:options,
               trueOption:type === 'checkbox'?[]:null,
           }
           this.questionList.push(question)
           this.currentQuestion=question;
       },
        changeQuestion(k){
           var q=this.questionList[k];
           this.currentQuestion=q;
        },
        submit(){
           {
               //校验
               if(!this.title){
                   return alert('试卷标题不能为空');
               }
               for (var i=0;i<this.questionList.length;i++){
                   var q=this.questionList[i];
                   if (!q.questionTitle){
                       return  alert(`第${i+1}题的题干没有填写`);
                   }
                   if (q.score<=0){
                       return alert(`第${i+1}题的分数设置错误`);
                   }
                   //判断选项
                   for (var j=0;j<q.options.length; j++){
                       var o=q.options[j];
                       if (!o.value){
                           return alert(`第${i+1}题的${o.label}选项没有内容`);
                       }
                   }
                   //判断答案有没有设置
                   if (q.type==='checkbox' ){
                       if ( q.trueOption.length<=0){
                           return alert(`第${i+1}题的答案没有设置`);
                       }
                       q.answer=q.trueOption.join()
                   }else {
                       if (! q.trueOption){
                           return alert(`第${i+1}题的答案没有设置`);
                       }
                       q.answer = q.trueOption
                   }
               }
               $.ajax({
                   url:'/examination/create_new',
                   data:JSON.stringify( {
                       title: this.title,
                       questionList: this.questionTitle
                   }
                   ),
                   type: 'post',
                   contentType:'application/json',
                   success(resp){
                       console.log(resp);
                   }
               })

            }
        }
    }
})