var app = new Vue({
    el: '#app',
    data: {
        examiner_username: '', // 考官用户名
        examiner_password: '' // 考官密码
    },
    methods: {
        submit: function (event) {
            event.preventDefault(); // 防止默认的表单提交行为

            if (!this.examiner_username) { // 判断用户名是否为空或undefined
                return alert('请输入用户名');
            }
            if (!this.examiner_password || this.examiner_password.length < 6 || this.examiner_password.length > 20) { // 判断密码是否符合要求
                return alert('密码不正确，且必须6-20位');
            }

            // 发送数据
            $.ajax({
                url: '/examiner', // 将请求URL改为正确的接口地址
                data: JSON.stringify({ // 将登录数据转换成JSON格式
                    username: this.examiner_username, // 修改属性名，与后端代码对应
                    password: this.examiner_password
                }),
                contentType: 'application/json', // 指定请求体的类型为JSON
                method: 'POST', // 将请求方法改为POST
                success: function (resp) {
                    if (resp && resp.message) {
                        alert(resp.message);
                    } else {
                        alert('登录成功');
                        location.href='examination_list.html';
                    }

                },
                error: function () {
                    alert('请求失败');
                }
            });
        }
    }
});