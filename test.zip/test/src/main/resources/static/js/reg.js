var app =new Vue({
    el:'#app',
    data:{
        student_number:'',//学号
        name:'',//姓名
        password:'',//密码
        confirmPassword:''//确认密码
    },
    methods:{
        submit(){
            console.log('准备提交数据')

            console.log('用户名是:'+this.student_number)
            console.log('姓名是:'+this.name)
            console.log('密码是:'+this.password)
            console.log('确认密码是:'+this.confirmPassword)
    if (this.password!==this.confirmPassword){
        return alert('两次密码不一致');
    }
    //发送数据
            $.ajax({
                url:'/reg',
                    data:{
                        student_number:this.student_number,//学号
                        name:this.name,//姓名
                        password:this.password,//密码
                        confirmPassword:this.confirmPassword//确认密码
                    },
                dataType:'text',
                    method:'POST',
                    success(resp){
                    alert(resp)
                }
            })
}
    }
})


