var app = new Vue({
    el: '#app',
    data: {
        student_number: '', // 学号
        password: '', // 密码

    },
    methods: {
        submit: function () {
            if (this.student_number == '') {
                return alert('请输入学号')
            }
            if (this.password == '' || this.password.length < 6 || this.password.length > 20) {
                return alert('密码不正确，且必须6-20位');
            }
            $.ajax({
                url: '/login',
                data: {
                    student_number: this.student_number, // 学号
                    password: this.password // 密码
                },
                dataType: 'text',
                method: 'POST',
                success: function (resp) {
                    alert(resp)
                }
            })
        }

    }
});